python  insane.py -f  apt2-martinized.pdb -o mito-membrane.gro -p topol-mito.top  -l POPC:40  -l POPE:34  -l CDL2:18 -sol PW  -box  13,13,19  -pbc square  -dm 6
