python  insane.py -f  apt2-martinized.pdb -o golgi-membrane.gro  -p topol-golgi.top  -l POPC:50  -l POPE:20  -l POPI:12 -sol PW  -box  13,13,19  -pbc square  -dm 6

